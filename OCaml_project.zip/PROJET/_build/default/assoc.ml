(***********************)
(* Projet 2I008, 18/19 *)
(***********************)

(** Ce fichier contient une structure de map (int -> 'a), les paires
    clé/valeur sont stockés dans une liste ordonnée sur les clés. *)

(* à compléter *)
let rec remove_assoc (k : int) (l : (int * 'a) list) : (int * 'a) list =
  match l with
  |[] -> []
  |(i, a)::xs -> if i = k then xs
    else if i > k then l
    else (i, a)::(remove_assoc k xs)


(* à ne pas toucher *)
let pp_assoc
    (pp1: Format.formatter -> 'a -> unit)
    (fmt: Format.formatter)
    (l: (int * 'a) list): unit =
  Format.fprintf fmt "@[[%a@]]"
    (Format.pp_print_list
       ~pp_sep:(fun fmt () -> Format.fprintf fmt ",")
       (fun fmt (k, v) -> Format.fprintf fmt "(%a, %a)" Format.pp_print_int k pp1 v)
    ) l

(* Définition du type des fonctions des entiers vers 'a *)
type 'a t =
  { assoc : (int * 'a) list;
    default : 'a
  }
(* à compléter *)
let constant (d : 'a): 'a t =
  {default = d; assoc = []}

(* à compléter *)
let rec find (k : int) (m : 'a t): 'a =
  match m.assoc with
  |[] -> m.default
  |(i, a)::xs -> if i = k then a
    else if i > k then m.default
    else find k {m with assoc = xs}

(* à compléter *)
let set (k : int) (v : 'a) (m : 'a t): 'a t =
  let rec loop k1 v1 m1 accu =
    match m1.assoc with
    |[] -> if v <> m1.default then {m1 with assoc = accu@[(k1, v1)]}
      else {m1 with assoc = accu}
    |(i, a)::xs -> if v1 = m1.default then
        (if i = k1 then {m1 with assoc = accu@(remove_assoc k1 m1.assoc)}
        else if i > k1 then m1
        else (loop k1 v1 {m1 with assoc = xs} (accu@[(i, a)])))
      else if i = k1 then {m1 with assoc = accu@((i, v)::xs)}
      else if i > k1 then {m1 with assoc = accu@((k1, v1)::(i, a)::xs)}
      else (loop k1 v1 {m1 with assoc = xs} (accu@[(i, a)]))
  in loop k v m []

(* à compléter *)
let rec fold (f : int -> 'a -> 'b -> 'b) (a : int) (b : int) (m : 'a t) (init : 'b): 'b =
    if a = b then (f b (find b m) init)
    else (f b (find b m) (fold f a (b-1) m init))

(* à ne pas toucher *)
let pp
    (pp1: Format.formatter -> 'a -> unit)
    (fmt: Format.formatter)
    (m: 'a t): unit =
  Format.fprintf fmt "@[{default:%a;@, assoc:[@[%a@]]@,}@]"
    pp1 m.default
    (Format.pp_print_list
       ~pp_sep:(fun fmt () -> Format.fprintf fmt ",@,")
       (fun fmt (k, v) -> Format.fprintf fmt "(%a, %a)" Format.pp_print_int k pp1 v)
    ) m.assoc
