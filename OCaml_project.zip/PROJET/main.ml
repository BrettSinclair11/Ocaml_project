open Boulder_dash
open Type
open Graphics

let handle (_: Graphics.status) (_: game) =
  (* mouvement du joueur *)
  (* mouvements du monde *)
  assert false

let rec turn g =
  let st = wait_next_event [Key_pressed] in
  let g = handle st g in
  let scale = Drawing.compute_scaler g in
  Drawing.reinit_graphics ();
  let () = Drawing.draw_game g scale in
  turn g

let game ()  =
  let game = Parse.parse_file "data/level0.lv" in
  Drawing.init_graphics ();
  let scale = Drawing.compute_scaler game in
  Drawing.reinit_graphics ();
  let () = Drawing.draw_game game scale in
  turn game

let () =
  game ()
