(***********************)
(* Projet 2I008, 18/19 *)
(***********************)

(** Ce fichier contient les fonctions d'affichage graphique du jeu *)

open Graphics
open Type
open Structures

type scale = (int * int) -> (int * int)

let gray    = rgb 105 105 105
let brown   = rgb 91  60  17
let walnut  = rgb 167 103 38
let diamond = rgb 185 242 255

let compute_scaler (g: game): scale =
  let sx = size_x () in
  let sy = size_y () in
  let rx = (sx - sx / 5) / g.map.larg in
  let ry = (sy - sy / 5) / g.map.haut in
  let sxi = rx * g.map.larg in
  let syi = ry * g.map.haut in
  let margx = (sx - sxi) / 2 in
  let margy = (sy - syi) / 2 in
  fun (x, y) ->
    (margx + x * rx, margy + y * ry)


let draw_rect_cell (c : color) ((i, j) : int * int) (scaler : scale): unit =
  Graphics.set_color c;
  let (i1,j1) = scaler (i,j) in
  let (w1,h1) = scaler (1,1) in
  Graphics.draw_rect i1 j1 w1 h1


let fill_rect_cell (c : color) ((i, j) : int * int) (scaler : scale): unit =
Graphics.set_color c;
let (i1,j1) = scaler (i,j) in
let (w1,h1) = scaler (1,1) in
Graphics.fill_rect i1 j1 w1 h1


let fill_diamond_cell (c : color) ((i, j) : int * int) (scaler : scale): unit =
  Graphics.set_color c;
  let (i1,j1) = scaler (i,j) in
  let (i2,j2) = scaler (i+1,j+1) in
  Graphics.fill_poly [|((i1+i2)/2,j1);(i1,(j1+j2)/2);((i1+i2)/2,j2);(i2,(j1+j2)/2)|]


let fill_circle_cell (c : color) ((i, j) : int * int) (scaler : scale): unit =
  Graphics.set_color c;
  let (i1,j1) = scaler (i,j) in
  let (i2,j2) = scaler (i+1,j+1) in
  Graphics.fill_circle ((i1+i2)/2) ((j1+j2)/2) (i2-i1)

let fill_ellipse_cell (c : color) ((i, j) : int * int) (scaler : scale): unit =
	Graphics.set_color c;
	let (i1,j1) = scaler (i,j) in
	let (i2,j2) = scaler (i+1,j+1) in
	Graphics.fill_ellipse ((i1 + i2) / 2) ((j1 + j2) / 2) (1 / 3) 1

let draw_cell (c : cell) ((i, j) : int * int) (scaler : scale): unit =
  match c with
  |Stone   -> fill_rect_cell black 		(i, j) scaler
  |Boulder -> fill_circle_cell gray 	(i, j) scaler
  |Dirt    -> fill_rect_cell brown 		(i, j) scaler
  |Diamond -> fill_diamond_cell diamond (i, j) scaler
  |Walnut  -> fill_ellipse_cell walnut  (i, j) scaler
  |Empty   -> draw_rect_cell black 		(i, j) scaler


let draw_map (m : map) (scaler : scale): unit =
  Matrix.iter (fun i j _ -> draw_cell (Matrix.read i j m) (i,j) scaler) m


let draw_player ((i, j) : (int * int)) (scaler : scale): unit =
  fill_circle_cell red (i,j) scaler


let draw_game (g : game) (scaler : scale) =
  let (i, j) = scaler (g.map.haut, 0) in
  moveto i j;
  draw_string (string_of_int (count_diamonds g.map));
  fill_diamond_cell diamond (i, j + 2) scaler;
  draw_map g.map scaler;
  draw_player g.player scaler;
  Graphics.synchronize


let init_graphics (): unit =
  Graphics.open_graph "";
  Graphics.auto_synchronize false


let reinit_graphics (): unit =
  Graphics.clear_graph ()
