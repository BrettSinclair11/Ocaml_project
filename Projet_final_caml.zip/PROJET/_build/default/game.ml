open Type
open Structures


exception Dead
exception Win


let position_after_move ((i, j) : (int * int)) (dir : dir) : (int * int) =
  match dir with
  |E -> (i, j + 1)
  |W -> (i, j - 1)
  |N -> (i + 1, j)
  |S -> (i - 1, j)


let player_turn (game : game) (dir : dir) : game =
  let (i, j) = (position_after_move game.player dir) in
  match (Matrix.read i j game.map) with
  |Empty   -> {game with player = (i, j)}
  |Dirt    -> {game with map = (Matrix.set i j Empty game.map); player = (i, j)}
  |Diamond -> if ((cout_diamonds game.map) = 1) then
  				raise Win
  			  else {game with map = (Matrix.set i j Empty game.map); player = (i, j); diamonds = (diamonds - 1)}
  |Stone   -> game
  |Boulder -> if (dir = E) then
                (if ((Matrix.read i (j + 1) game.map) = Empty) then
                  {game with map = (Matrix.set i (j + 1) Boulder (Matrix.set i j Empty game.map)); player = (i, j)}
                else game)
              else if (dir = W) then
                (if ((Matrix.read i (j - 1) game.map) = Empty) then
                  {game with map = (Matrix.set i (j - 1) Boulder (Matrix.set i j Empty game.map)); player = (i, j)}
                else game)
              else game


let is_empty ((i, j) : (int * int)) (game : game) : bool =
  (game.player <> (i, j) && (Matrix.read i j game.map) = Empty)


let position_after_fall (game : game) ((i, j) : (int * int)) : (int * int) =
  match (Matrix.read (i - 1) j game.map) with
  |Empty -> if (game.player <> (i - 1, j)) then (i -1, j)
            else (i, j)
  |Boulder -> if (is_empty ((i - 1), (j - 1)) game) then
                (i - 1, j - 1)
              else if (is_empty ((i - 1), (j + 1)) game) then
                (i - 1, j + 1)
              else (i, j)
  |_ -> (i, j)


let move_boulder_step (game : game) ((i, j) : (int * int)) : game =
  let (ni, nj) = position_after_fall game (i, j) in
  if (game.player = (ni, nj)) then
    raise Dead
  else
	match (Matrix.read ni (nj - 1) m) with
	| Walnut -> {game with map = (Matrix.set ni (nj - 1) Diamond (Matrix.set ni nj Boulder (Matrix.set i j Empty game.map)))}
	| _ ->{game with map = (Matrix.set ni nj Boulder (Matrix.set i j Empty game.map))}


let find_movable_boulder (game : game) : (int * int) option =
  Matrix.fold (fun i j a accu -> if ((position_after_fall game (i, j)) <> (i, j)) then
                  Some (position_after_fall game (i, j))
                else None) game.map None


let world_turn (game : game) : game =
  if (win game) then raise Win
	else (
	let g = ref game in
  while ((find_movable_boulder game) <> None) do
    match (find_movable_boulder game) with
    |Some (i,j) -> g := move_boulder_step !g (i,j);
    			   draw_game !g (compute_scaler !g);
    			   Unix.sleepf 1.5
    |None       -> ()
  done;
   !g)


let win (game : game) : bool =
  game.diamonds = 0


let count_diamonds (m : map) : int =
	Matrix.fold (fun i j m accu -> match (Matrix.read i j m) with
																	| Diamond -> (accu + 1)
																	| Walnut  -> (accu + 1)
																	| _       ->  accu) m 0
