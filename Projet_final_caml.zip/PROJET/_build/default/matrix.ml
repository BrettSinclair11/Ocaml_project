(***********************)
(* Projet 2I008, 18/19 *)
(***********************)

(** Ce fichier contient une structure de matrice implanté à l'aide de
    maps. *)

(* Définition de type *)
type 'a t =
  {
    larg    : int;
    haut    : int;
    map     : ('a Assoc.t) Assoc.t;
  }


exception Out_of_bounds


(* à ne pas toucher *)
let pp
    (pp1: Format.formatter -> 'a -> unit)
    (fmt: Format.formatter)
    (m  : 'a t): unit =
  Format.fprintf fmt "@[<v 2>{@,larg:%d@,haut:%d@,m:%a}}@]"
    m.larg
    m.haut
    (Assoc.pp (Assoc.pp pp1)) m.map


let make (haut : int) (larg : int) (default : 'a): 'a t=
  {larg=larg;haut=haut;map={assoc = []; default = Assoc.constant default}}


let read (i : int) (j : int) (m : 'a t): 'a =
  Assoc.find j (Assoc.find i m.map)


let set (i : int) (j : int) (v : 'a) (m : 'a t): 'a t =
  {m with map = (Assoc.set i (Assoc.set j v (Assoc.find i m.map)) m.map)}


let fold (f : int -> int -> 'a -> 'b -> 'b) (m : 'a t) (acc : 'b): 'b =
  let rec loop h l acc =
    if h = m.haut then acc
    else if l = m.larg then loop (h+1) 0 acc
    else loop h (l+1) (f h l (read h l m) acc)
  in loop 0 0 acc

  (*Assoc.fold (fun i l acc -> Assoc.fold (fun j v acc -> f i j v l ) 0 (m.larg-1) (Assoc.find i m.map) acc) 0 (m.haut-1) m.map acc*)

let iter (f : int -> int -> 'a -> unit) (m : 'a t): unit =
  fold (fun a b c () -> f a b c) m ()
