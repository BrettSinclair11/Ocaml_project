open Boulder_dash
open Type
open Graphics

exception Close

let handle (st : Graphics.status) (game1 : game) =
  let dir = ref E in
	if (not (st.keypressed)) then game1
	else (
	match st.key with
	| 'z' -> dir := N
	| 's' -> dir := S
	| 'd' -> dir := E
	| 'q' -> dir := W
	| 'x' -> raise Close
	|_    -> game1 
	);
	let game2 = ref game1 in
	game2 := player_turn game2 dir;
	game2 := world_turn game2;
	game2

let rec turn g =
  let st = wait_next_event [Key_pressed] in
  let g = handle st g in
  let scale = Drawing.compute_scaler g in
  Drawing.reinit_graphics ();
  let () = Drawing.draw_game g scale in
  turn g

let game ()  =
  let game = Parse.parse_file "data/level0.lv" in
  Drawing.init_graphics ();
  let scale = Drawing.compute_scaler game in
  Drawing.reinit_graphics ();
  let () = Drawing.draw_game game scale in
	try
		turn game
	with
	| Close -> close_in "data/level0.lv"
	| Win   -> print_string "Gagné"; close_in "data/level0.lv"
	| Dead  -> print_string "Perdu"; close_in "data/level0.lv"

let () =
  game ()
